<?php
    require_once 'Model/Noticia.php';    
?>

<!DOCTYPE HTML>

<html>
    <head>
        <title>Noticias | Aceites Málaga</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
        <link rel="shortcut icon" href="css/imagenes/favicon.png">
        <!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/skel.min.js"></script>
        <script src="js/skel-panels.min.js"></script>
        <script src="js/init.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <script src="paginadorIndex.js" type="text/javascript"></script>
        
        <script src="js/banner.js" type="text/javascript"></script>
        <script src="leerMas/js/jquery.sudoSlider.min.js" type="text/javascript"></script>
        <link href="css/slide.css" rel="stylesheet" type="text/css"/>
        
        <noscript>
        <link rel="stylesheet" href="css/skel-noscript.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/style-desktop.css" />
        <!--<link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css" />-->
        </noscript>
        <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
        <!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
    </head>
    <body>

        <!-- Header -->
        <div id="header">
            <div class="container">

                <!-- Logo -->
                <div id="logo">
                    <a href="#"><img id="logoImg" src="css/imagenes/acm.png"></a>
                </div>

                <!-- Nav -->
                <nav id="nav">
                    <ul>
                        <li class="active"><a href="index.php">INICIO</a></li>
                        <li><a href="http://aceitesmalaga.com/">NOSOTROS</a></li>
                        <li><a href="#">TIENDA</a></li>
                    </ul>
                </nav>

            </div>
        </div>
        <hr>
        <!-- Header -->
            <div id="slider" >
                <ul>
                    <li><img src="1.jpg" height="200px" style="width: 100%;" alt=""/></li>
                    <li><img src="2.jpg" height="200px" style="width: 100%;" alt=""/></li>
                    <li><img src="3.jpg" height="200px" style="width: 100%;" alt=""/></li>	
                </ul>
            </div>
        

        <div id="featured">
            <div class="container">
                <div class="row">
                    <div class="9u">
                        <section>
                            <?php
                            $data['noticias'] = Noticia::getUltimaNoticia();
                            foreach ($data['noticias'] as $noticia) {
                                ?>

                                <header>
                                    <h2><?= $noticia->getTitulo() ?></h2>
                                    <?php
                                        if ($noticia->getFechaModificacion() == null){
                                           ?>     
                                            <span><b>Fecha de creación: </b><?= $noticia->getFecha() ?></span>
                                            <?php
                                        }else{
                                            ?>     
                                            <span><b>Fecha de creación: </b><?= $noticia->getFecha() ?></span>
                                            <br>
                                            <span id="ultimaEdicion">Última edición: <?= $noticia->getFechaModificacion() ?></span>
                                            <?php
                                        }
                                        
                                    ?>
                                </header>
                                <?php
                                if ($noticia->getImagen() != null) {
                                ?>
                                    <a href="#" class="image full"><img src="images/<?= $noticia->getImagen() ?>" alt=""></a>
                                <?php
                                }
                                ?>
                                <p><?= substr($noticia->getDescripcion(), 0, 1000) ?>...</p>
                                <a href="leerMas/index.php?id=<?= $noticia->getIdNoticia() ?>" class="readMore"><span>Leer más</span></a>
                               <?php
                            }
                            ?>	
                            <div id="contenido">
                                <?php include('paginadorIndex.php') ?>
                            </div>
                        </section>
                    </div>
                    <div class="3u">
                        <section>
                            <header>
                                <h2 id="noticasMasLeidas">Noticias más leidas</h2>
                            </header>
                        </section>
                        <?php
                        $data['noticias'] = Noticia::getNoticiasMasLeidas();
                        foreach ($data['noticias'] as $noticia) {
                            ?>
                            <section>
                                <?php
                                if ($noticia->getImagen() != null) {
                                ?>
                                <a href="#" class="image full"><img src="images/<?= $noticia->getImagen() ?>" alt=""></a>
                                <?php
                                }
                                ?>
                                <header>
                                    <h2><?= $noticia->getTitulo() ?></h2>
                                </header>
                                <?= substr($noticia->getDescripcion(), 0, 200) ?>...<br>
                                <a href="leerMas/index.php?id=<?= $noticia->getIdNoticia() ?>" class="readMore"><span>Leer más</span></a>
                            </section>
                            <br><br><br>   

                            <?php
                        }
                        ?>	
                    </div>		
                </div>
            </div>
        </div>

        <!-- Copyright -->
        <div id="copyright">
            <div class="container">
                <div class="rowFooter" id="row1">
                    <span>Copyright © Aceites Málaga,S.L.</span>
                </div>
                <div class="rowFooter" id="row2">
                    <ul>
                        <li><i class="fa fa-twitter" id="twitterFooter"></i></li>
                        <li><i class="fa fa-facebook" id="facebookFooter"></i></li>
                        <li><i class="fa fa-google-plus" id="gFooter"></i></li>
                    </ul>

                </div>
                <div class="rowFooter" id="row3">
                    <ul>
                        <li>Politica de cookies</li>
                        <li>Politica de privacidad</li>
                        <li>Términos de uso</li>
                    </ul>
                </div>
            </div>	
        </div>

    </body>
</html>