
<?php
require_once 'Model/BlogDB.php';
$connection = BlogDB::connectDB();

if (isset($_GET['id'])) {
    $RegistrosAMostrar = 4;

//estos valores los recibo por GET
    if (isset($_GET['pag'])) {
        $RegistrosAEmpezar = ($_GET['pag'] - 1) * $RegistrosAMostrar;
        $PagAct = $_GET['pag'];
//caso contrario los iniciamos
    } else {
        $RegistrosAEmpezar = 0;
        $PagAct = 1;
    }
    $idNoticia = $_GET['id'];
    $Resultado = $connection->query("SELECT * FROM comentarios WHERE idNoticia = $idNoticia ORDER BY idComentario DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");
    ?>
    <table id="tableAdmin">  
    <?php
    while ($MostrarFila = $Resultado->fetchObject()) {
        ?>
            <tr id="comentarioPanelAdmin<?= $MostrarFila->idComentario ?>">
                <td id="fechaAdmin"><?= $MostrarFila->fecha ?></td>
                <td id="tituloAdmin"><?= substr($MostrarFila->comentario, 0, 100) ?>...</td>
                <td class="iconosFa"><i id="borrar" class="fa fa-close" name="<?= $MostrarFila->idComentario ?>"></i></td>
            </tr>
        <?php
    }
    ?>
    </table>
        <?php
//******--------determinar las p�ginas---------******//
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM comentarios WHERE idNoticia = $idNoticia");
        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1',$idNoticia)\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt',$idNoticia)\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt)
            echo "<button onclick=\"Pagina('$PagSig',$idNoticia)\">Siguiente</button> ";
        if ($PagUlt < 1) {
            echo "<button onclick=\"Pagina('1',$idNoticia)\">Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt',$idNoticia)\">Ultimo </button>";
        }
    }else{
        echo "<span class=pComentarios>"."No ha seleccionado ninguna noticia."."</span>";
        echo "<p class=pComentarios>"."Seleccione una noticia para ver los comentarios"."</p>";
    }
    ?>
