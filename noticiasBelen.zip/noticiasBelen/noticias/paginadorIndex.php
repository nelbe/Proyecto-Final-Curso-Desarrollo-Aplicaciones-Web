
<?php

require_once 'Model/BlogDB.php';
$connection = BlogDB::connectDB();

$RegistrosAMostrar=4;

//estos valores los recibo por GET
if(isset($_GET['pag'])){
	$RegistrosAEmpezar=($_GET['pag']-1)*$RegistrosAMostrar;
	$PagAct=$_GET['pag'];
//caso contrario los iniciamos
}else{
	$RegistrosAEmpezar=0;
	$PagAct=1;
	
}
$Resultado= $connection->query("SELECT * FROM noticias ORDER BY fecha DESC, idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");
echo "<table border='1px'>";
while($MostrarFila=$Resultado->fetchObject()){
	echo "<tr>";
        echo "<td class='date'>".$MostrarFila->fecha."</td>";
	echo "<td class='titulo'>"."<a href='leerMas/index.php?id=$MostrarFila->idNoticia'>".$MostrarFila->titulo."</a>"."</td>";
	echo "</tr>";
}
echo "</table>";
//******--------determinar las p�ginas---------******//
$consultaNumRegistro=$connection->query("SELECT count(*)AS Registros FROM noticias");
while($MostrarFila=$consultaNumRegistro->fetchObject()){
   $NroRegistros= $MostrarFila->Registros;
}

$PagAnt=$PagAct-1;
$PagSig=$PagAct+1;
$PagUlt=$NroRegistros/$RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
$Res=$NroRegistros%$RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
if($Res>0) $PagUlt=floor($PagUlt)+1;

//desplazamiento
echo "<button onclick=\"Pagina('1')\">Primero</button> ";
if($PagAct>1) echo "<button onclick=\"Pagina('$PagAnt')\">Anterior</button> ";
echo "<strong>Pagina ".$PagAct."/".$PagUlt."</strong>";
if($PagAct<$PagUlt)  echo "<button onclick=\"Pagina('$PagSig')\">Siguiente</button> ";

if ($PagUlt==0){
    echo "<button>Ultimo</button>";
}else{
    echo "<button onclick=\"Pagina('$PagUlt')\">Ultimo </button>";
}

?>
