<?php
require_once 'BlogDB.php';

class Comentario {
  private $idComentario;
  private $usuario;
  private $fecha;
  private $comentario;
  private $idNoticia;
  private $idUsuarioFacebook;
  private $email;
  
 //Constructor
  function __construct($idComentario, $usuario, $fecha, $comentario,$idNoticia,$idUsuarioFacebook,$email) {
    $this->idComentario = $idComentario;
    $this->usuario = $usuario;
    $this->fecha = $fecha;
    $this->comentario = $comentario;
    $this->idNoticia = $idNoticia;
    $this->idUsuarioFacebook = $idUsuarioFacebook;
    $this->email = $email;
    
    }
    
    function getIdComentario() {
        return $this->idComentario;
    }

    function getUsuario() {
        return $this->usuario;
    }

    function getFecha() {
        return $this->fecha;
    }

    function getComentario() {
        return $this->comentario;
    }
    
    function getIdNoticia() {
        return $this->idNoticia;
    }

    function getIdUsuarioFacebook() {
        return $this->idUsuarioFacebook;
    }

    function getEmail() {
        return $this->email;
    }

        
    public function insert() {
    $conexion = BlogDB::connectDB();
    $insercion = "INSERT INTO comentarios (usuario, fecha, comentario, idNoticia, idUsuarioFacebook, email) VALUES (\"".$this->usuario."\",CURRENT_TIMESTAMP , \"".$this->comentario."\", \"".$this->idNoticia."\", \"".$this->idUsuarioFacebook."\", \"".$this->email."\")";
  
    $conexion->exec($insercion);
    } 
    
    public static function getComentariosByID($idNoticia) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idComentario, usuario, fecha, comentario, idNoticia, idUsuarioFacebook, email FROM comentarios WHERE idNoticia = $idNoticia  order by fecha DESC, idComentario DESC";
    $consulta = $conexion->query($seleccion);
    
    $comentarios = [];
    
    while ($registro = $consulta->fetchObject()) {
      $comentarios[] = new Comentario($registro->idComentario, $registro->usuario, $registro->fecha, $registro->comentario, $registro->idNoticia, $registro->idUsuarioFacebook, $registro->email);
    }
   
    return $comentarios;    
  }
  
  public function deleteComentario() {
    $conexion = BlogDB::connectDB();
    $borrado = "DELETE FROM comentarios WHERE idComentario=\"".$this->idComentario."\"";
    $conexion->exec($borrado);
  }
  
  public function update() { 
    $conexion = BlogDB::connectDB();
    $modificado = "UPDATE comentarios SET idComentario=\"".$this->idComentario."\",usuario=\"".$this->usuario."\",fecha=\"".$this->fecha."\",comentario=\"".$this->comentario."\",idNoticia=\"".$this->idNoticia."\",idUsuarioFacebook=\"".$this->idUsuarioFacebook."\",email=\"".$this->email."\" WHERE idComentario=\"".$this->idComentario."\"";
    
    $conexion->exec($modificado);
  
  }
}

