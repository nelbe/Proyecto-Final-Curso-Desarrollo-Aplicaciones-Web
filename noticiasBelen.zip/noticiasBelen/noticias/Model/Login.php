<?php

require_once 'BlogDB.php';
//Atributos
class Login {
  private $idUsuario;
  private $email;
  private $password;
  private $permiso;
//Constructor
  function __construct($idUsuario, $email, $password, $permiso) {
    $this->idUsuario = $idUsuario;
    $this->email = $email;
    $this->password = $password;
    $this->permiso = $permiso;
  }
  function getIdUsuario() {
      return $this->idUsuario;
  }

  function getEmail() {
      return $this->email;
  }

  function getPassword() {
      return $this->password;
  }

  function getPermiso() {
      return $this->permiso;
  }

 
 
  public static function getUsuarioByEmail($correo) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idUsuario, email, password, permiso FROM usuarios WHERE email=\"".$correo."\"";
    $consulta = $conexion->query($seleccion);
    
    $usuarios = [];
    
    while ($registro = $consulta->fetchObject()) {
      $usuarios[] = new Login($registro->idUsuario, $registro->email, $registro->password, $registro->permiso);
    }
   
    return $usuarios;    
  }
  
  
}
