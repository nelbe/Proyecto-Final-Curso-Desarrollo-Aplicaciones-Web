<?php

require_once 'BlogDB.php';
//Atributos
class Imagen {
  private $idImagen;
  private $idNoticia;
  private $nombre;
//Constructor
  function __construct($idImagen, $idNoticia, $nombre) {
    $this->idImagen = $idImagen;
    $this->idNoticia = $idNoticia;
    $this->nombre = $nombre;
    
  }
  
  function getIdImagen() {
      return $this->idImagen;
  }

  function getIdNoticia() {
      return $this->idNoticia;
  }

  function getNombre() {
      return $this->nombre;
  }

    public function insert() {
    $conexion = BlogDB::connectDB();
    $insercion = "INSERT INTO imagenes (idNoticia, nombre) VALUES ('$this->idNoticia','$this->nombre')";
    //echo $insercion;
    //die();
    $conexion->exec($insercion);
    }
    
    public static function getNombreImagenByIdNoticia($id) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT nombre FROM imagenes WHERE idNoticia=\"".$id."\"";
    $consulta = $conexion->query($seleccion);
    
    $imagenes = [];
    
    while ($registro = $consulta->fetchObject()) {
      $imagenes[] = new Imagen("","",$registro->nombre);
    }
   
    return $imagenes;    
  }
  
  public static function getImagenesByIdNoticia($idNoticia) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idImagen, idNoticia, nombre FROM imagenes WHERE idNoticia = $idNoticia";
    $consulta = $conexion->query($seleccion);
    
    $imagenes = [];
    
    while ($registro = $consulta->fetchObject()) {
      $imagenes[] = new Imagen($registro->idImagen, $registro->idNoticia, $registro->nombre);
    }
   
    return $imagenes;    
  }
  
  public function deleteImagen() {
    $conexion = BlogDB::connectDB();
    $borrado = "DELETE FROM imagenes WHERE idImagen=\"".$this->idImagen."\"";
    $conexion->exec($borrado);
  }
  
}
