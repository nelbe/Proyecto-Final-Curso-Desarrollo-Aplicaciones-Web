<?php

require_once 'BlogDB.php';
//Atributos
class Usuario {
  private $idUsuario;
  private $email;
  private $password;
  private $permiso;
  private $nombre;
//Constructor
  function __construct($idUsuario, $email, $password, $permiso, $nombre) {
    $this->idUsuario = $idUsuario;
    $this->email = $email;
    $this->password = $password;
    $this->permiso = $permiso;
    $this->nombre = $nombre;
  }
  function getIdUsuario() {
      return $this->idUsuario;
  }

  function getEmail() {
      return $this->email;
  }

  function getPassword() {
      return $this->password;
  }

  function getPermiso() {
      return $this->permiso;
  }
  
  function getNombre() {
      return $this->nombre;
  }


  public static function getUsuarios() {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idUsuario,email, password, permiso, nombre FROM usuarios";
    $consulta = $conexion->query($seleccion);
    
    $usuarios = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Usuario($registro->idUsuario, $registro->email, $registro->password, $registro->permiso, $registro->nombre);
    } //Aquí ponía new Noticia y lo he cambiado, por si falla algo
   
    return $usuarios;    
  }
  
 
  public static function getNombreUsuarioByIdUsuario($id) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT nombre FROM usuarios WHERE idUsuario=\"".$id."\"";
    $consulta = $conexion->query($seleccion);
    
    $usuarios = [];
    
    while ($registro = $consulta->fetchObject()) {
      $usuarios[] = new Usuario("","","","",$registro->nombre);
    }
   
    return $usuarios;    
  }
  
  //Este método lo uso para el formulario de modificación de usuarios en el panel de admin
  public static function getUsuarioById($id) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT * FROM usuarios WHERE idUsuario=\"".$id."\"";
    $consulta = $conexion->query($seleccion);
    
    $usuarios = [];
    
    while ($registro = $consulta->fetchObject()) {
      $usuarios[] = new Usuario($registro->idUsuario, $registro->email, $registro->password, $registro->permiso, $registro->nombre);
    }
   
    return $usuarios;    
  }
  
  public function insert() {
    $conexion = BlogDB::connectDB();
    $insercion = "INSERT INTO usuarios (idUsuario,email, password, permiso, nombre) VALUES ('$this->idUsuario','$this->email', '$this->password', '$this->permiso', '$this->nombre')";
    //echo $insercion;
    //die();
    $conexion->exec($insercion);
  }
  
  public function deleteUsuario() {
    $conexion = BlogDB::connectDB();
    $borrado = "DELETE FROM usuarios WHERE idUsuario=\"".$this->idUsuario."\"";
    $conexion->exec($borrado);
  }
  
  public function update() { //CA
    $conexion = BlogDB::connectDB();
    $modificado = "UPDATE usuarios SET idUsuario=\"".$this->idUsuario."\",email=\"".$this->email."\",password=\"".$this->password."\",permiso=\"".$this->permiso."\",nombre=\"".$this->nombre."\" WHERE idUsuario=\"".$this->idUsuario."\"";
    
    $conexion->exec($modificado);
  }
  
  
}
