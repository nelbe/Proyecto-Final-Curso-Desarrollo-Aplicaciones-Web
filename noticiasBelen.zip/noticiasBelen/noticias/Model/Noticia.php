<?php

require_once 'BlogDB.php';
//Atributos
class Noticia {
  private $idNoticia;
  private $idUsuario;
  private $titulo;
  private $imagen;
  private $descripcion;
  private $fecha;
  private $video;
  private $fechaModificacion;
  private $visita;
//Constructor
  function __construct($idNoticia, $idUsuario, $titulo, $fecha, $descripcion, $imagen, $fechaModificacion, $video,$visita) {
    $this->idNoticia = $idNoticia;
    $this->idUsuario = $idUsuario;
    $this->titulo = $titulo;
    $this->imagen = $imagen;
    $this->descripcion = $descripcion;
    $this->fecha = $fecha;
    $this->video = $video;
    $this->fechaModificacion = $fechaModificacion;
    $this->visita = $visita;
    }
    function getIdNoticia() {
        return $this->idNoticia;
    }
    
    function getIdUsuario() {
        return $this->idUsuario;
    }

    function getTitulo() {
        return $this->titulo;
    }

    function getImagen() {
        return $this->imagen;
    }

    function getDescripcion() {
        return $this->descripcion;
    }

    function getFecha() {
        return $this->fecha;
    }

    function getVideo() {
        return $this->video;
    }
    function getFechaModificacion() {
        return $this->fechaModificacion;
    }
    function getVisita() {
        return $this->visita;
    }

    
              
  public function insert() {
    $conexion = BlogDB::connectDB();
    $insercion = "INSERT INTO noticias (titulo, idUsuario, fecha, descripcion, imagen, fechaModificacion, video, visita) VALUES ('$this->titulo','$this->idUsuario', '$this->fecha', '$this->descripcion', '$this->imagen','$this->fechaModificacion', '$this->video', '$this->visita')";
    //echo $insercion;
    //die();
    $conexion->exec($insercion);
  }

  public function delete() {
    $conexion = BlogDB::connectDB();
    $borrado = "DELETE FROM noticias WHERE idNoticia=\"".$this->idNoticia."\"";
    $conexion->exec($borrado);
  }
  
  public static function getNoticias() {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idNoticia, idUsuario, titulo, fecha, descripcion, imagen, fechaModificacion, video, visita FROM noticias order by fecha DESC, idNoticia DESC";
    $consulta = $conexion->query($seleccion);
    
    $noticias = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Noticia($registro->idNoticia, $registro->idUsuario, $registro->titulo, $registro->fecha, $registro->descripcion, $registro->imagen, $registro->fechaModificacion, $registro->video, $registro->visita);
    }
   
    return $noticias;    
  }

  public static function getUltimaNoticia() {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idNoticia, idUsuario, titulo, fecha, descripcion, imagen, fechaModificacion, video, visita FROM noticias order by idNoticia desc LIMIT 1";
    $consulta = $conexion->query($seleccion);
    
    $noticias = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Noticia($registro->idNoticia, $registro->idUsuario, $registro->titulo, $registro->fecha, $registro->descripcion, $registro->imagen, $registro->fechaModificacion, $registro->video, $registro->visita);
    }
   
    return $noticias;    
  }
  
  public static function getLeerMas() {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idNoticia, idUsuario, titulo, fecha, descripcion, imagen, fechaModificacion, video, visita FROM noticias where idNoticia=$idNoticia";
    $consulta = $conexion->query($seleccion);
    
    $noticias = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Noticia($registro->idNoticia, $registro->idUsuario, $registro->titulo, $registro->fecha, $registro->descripcion, $registro->imagen, $registro->fechaModificacion, $registro->video, $registro->visita);
    }
   
    return $noticias;
    
  }
  
  public function update() { //CA
    $conexion = BlogDB::connectDB();
    $modificado = "UPDATE noticias SET idNoticia='$this->idNoticia',titulo='$this->titulo',fecha='$this->fecha',descripcion='$this->descripcion',fechaModificacion='$this->fechaModificacion', video='$this->video' WHERE idNoticia='$this->idNoticia'";
    
    $conexion->exec($modificado);
  }
  
  public static function getNoticiaById($id) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idNoticia, idUsuario, titulo, fecha, descripcion, imagen, fechaModificacion, video, visita FROM noticias WHERE idNoticia=\"".$id."\"";
    $consulta = $conexion->query($seleccion);
    
    $noticias = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Noticia($registro->idNoticia, $registro->idUsuario, $registro->titulo, $registro->fecha, $registro->descripcion, $registro->imagen, $registro->fechaModificacion, $registro->video, $registro->visita);
    }
   
    return $noticias;    
  }
  
  public static function getNoticiaByIdNoticia($idNoticia) {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idNoticia, idUsuario, titulo, fecha, descripcion, imagen, fechaModificacion, video, visita FROM noticias WHERE idNoticia=\"".$idNoticia."\"";
    $consulta = $conexion->query($seleccion);
    
    $noticias = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Noticia($registro->idNoticia, $registro->idUsuario, $registro->titulo, $registro->fecha, $registro->descripcion, $registro->imagen, $registro->fechaModificacion, $registro->video, $registro->visita);
    }
   
    return $noticias;    
  }
  
  public static function incrementarVisita($numeroVisita, $idNotcia) {
    $conexion = BlogDB::connectDB();
    $numeroVisita++;
    $modificado = "UPDATE noticias SET visita = $numeroVisita WHERE idNoticia = $idNotcia";
    $conexion->exec($modificado);
  }
  
   public static function getNoticiasMasLeidas() {
    $conexion = BlogDB::connectDB();
    $seleccion = "SELECT idNoticia, idUsuario, titulo, fecha, descripcion, imagen, fechaModificacion, video, visita FROM noticias ORDER BY visita DESC LIMIT 2";
    $consulta = $conexion->query($seleccion);
    
    $noticias = [];
    
    while ($registro = $consulta->fetchObject()) {
      $noticias[] = new Noticia($registro->idNoticia,$registro->idUsuario, $registro->titulo, $registro->fecha, $registro->descripcion, $registro->imagen, $registro->fechaModificacion, $registro->video, $registro->visita);
    }
   
    return $noticias;    
  }
  
  public function updateImagen() { 
    $conexion = BlogDB::connectDB();
    $modificado = "UPDATE noticias SET idNoticia='$this->idNoticia',imagen='$this->imagen' WHERE idNoticia='$this->idNoticia'";
    
    $conexion->exec($modificado);
  }
}
