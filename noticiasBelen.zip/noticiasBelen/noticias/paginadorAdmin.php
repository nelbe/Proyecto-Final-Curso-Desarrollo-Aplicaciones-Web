
<?php
require_once 'Model/BlogDB.php';
$connection = BlogDB::connectDB();
if(!isset($_SESSION)){
    session_start();
}

//Comprueba que existe login
if (isset($_SESSION['login'])){
    $idUsuario = $_SESSION['login']['idUsuario'];


//Datos del filtrado
if (isset($_GET["fecha"])) {
    $fecha = $_GET["fecha"];
}

if (isset($_GET["titulo"])) {
    $titulo = $_GET["titulo"];
}

$RegistrosAMostrar = 4;

//Sstos valores los recibo por GET
if (isset($_GET['pag'])) {
    $RegistrosAEmpezar = ($_GET['pag'] - 1) * $RegistrosAMostrar;
    $PagAct = $_GET['pag'];
//caso contrario los iniciamos
} else {
    $RegistrosAEmpezar = 0;
    $PagAct = 1;
}

//Consulta para el filtrado de Administrador

if ($_SESSION['login']['permiso'] == "administrador"){
    if (isset($fecha)) {

        $Resultado = $connection->query("SELECT * FROM noticias WHERE fecha = '$fecha' ORDER BY idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");

    } elseif(isset ($titulo)){

        $Resultado = $connection->query("SELECT * FROM noticias WHERE titulo LIKE '$titulo%' ORDER BY idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");

    } else {
        $Resultado = $connection->query("SELECT * FROM noticias ORDER BY idNoticia DESC, idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");
    }
}elseif (($_SESSION['login']['permiso'] == "editor")) { //Consulta para el filtrado de Editor
    if (isset($fecha)) {

        $Resultado = $connection->query("SELECT * FROM noticias WHERE fecha = '$fecha' AND idUsuario = $idUsuario ORDER BY idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");

    } elseif(isset ($titulo)){

        $Resultado = $connection->query("SELECT * FROM noticias WHERE titulo LIKE '$titulo%' AND idUsuario = $idUsuario ORDER BY idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");

    } else {
        $Resultado = $connection->query("SELECT * FROM noticias WHERE idUsuario = $idUsuario ORDER BY idNoticia DESC, idNoticia DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");
    }
}
?>
<table id="tableAdmin">  
<?php
while ($MostrarFila = $Resultado->fetchObject()) {
    ?>
        <tr id="noticiasPanelAdmin<?= $MostrarFila->idNoticia ?>">
            <td id="fechaAdmin"><?= $MostrarFila->fecha ?></td>
            <td id="tituloAdmin"><?= substr($MostrarFila->titulo, 0, 100) ?>...</td>
            <td class="iconosFa" ><a href="View/formularioModificarNoticia.php?id=<?= $MostrarFila->idNoticia ?>"><i class="fa fa-pencil"></i></a></td>
            <td class="iconosFa"><i id="borrar" class="fa fa-close" name="<?= $MostrarFila->idNoticia ?>"></i></td>
            <td class="iconosFa" ><a href="administrarComentarios.php?id=<?= $MostrarFila->idNoticia ?>"><i class="fa fa-commenting-o" id="iconComents"></i></a></td>
            <td class="iconosFa" ><a href="administrarGaleria.php?id=<?= $MostrarFila->idNoticia ?>"><i class="fa fa-picture-o" aria-hidden="true" id="iconImagen"></i></a></td>
        </tr>
    <?php
}
?>
</table>
    <?php
//******--------determinar las páginas---------******//
if ($_SESSION['login']['permiso'] == "administrador"){ //Paginaci�n administrador
    if (isset($fecha)) {
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM noticias WHERE fecha='$fecha'");
        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1','$fecha','fecha','false')\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt','$fecha','fecha','false')\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt) {
            echo "<button onclick=\"Pagina('$PagSig','$fecha','fecha','false')\">Siguiente</button> ";
        }

        if ($PagUlt == 0) {
            echo "<button>Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt','$fecha','fecha','false')\">Ultimo </button>";
        }
    }elseif (isset ($titulo)) {
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM noticias WHERE titulo='$titulo'");

        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1','false','titulo','$titulo')\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt','false','titulo','$titulo')\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt) {
            echo "<button onclick=\"Pagina('$PagSig','false','titulo','$titulo')\">Siguiente</button> ";
        }

        if ($PagUlt == 0) {
            echo "<button>Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt','false','titulo','$titulo')\">Ultimo </button>";
        }
        
    }else {
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM noticias");

        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1','false','todo')\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt','false','todo')\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt) {
            echo "<button onclick=\"Pagina('$PagSig','false','todo')\">Siguiente</button> ";
        }

        if ($PagUlt == 0) {
            echo "<button>Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt','false','todo')\">Ultimo </button>";
        }
    }
}  elseif ($_SESSION['login']['permiso'] == "editor"){ //Paginaci�n editor
    if (isset($fecha)) {
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM noticias WHERE fecha='$fecha' AND idUsuario=$idUsuario");
        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1','$fecha','fecha','false')\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt','$fecha','fecha','false')\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt) {
            echo "<button onclick=\"Pagina('$PagSig','$fecha','fecha','false')\">Siguiente</button> ";
        }

        if ($PagUlt == 0) {
            echo "<button>Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt','$fecha','fecha','false')\">Ultimo </button>";
        }
    }elseif (isset ($titulo)) {
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM noticias WHERE titulo='$titulo' AND idUsuario=$idUsuario");

        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1','false','titulo','$titulo')\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt','false','titulo','$titulo')\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt) {
            echo "<button onclick=\"Pagina('$PagSig','false','titulo','$titulo')\">Siguiente</button> ";
        }

        if ($PagUlt == 0) {
            echo "<button>Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt','false','titulo','$titulo')\">Ultimo </button>";
        }
        
    }else {
        $consultaNumRegistro = $connection->query("SELECT count(*)AS Registros FROM noticias WHERE idUsuario=$idUsuario");

        while ($MostrarFila = $consultaNumRegistro->fetchObject()) {
            $NroRegistros = $MostrarFila->Registros;
        }

        $PagAnt = $PagAct - 1;
        $PagSig = $PagAct + 1;
        $PagUlt = $NroRegistros / $RegistrosAMostrar;

//verificamos residuo para ver si llevar� decimales
        $Res = $NroRegistros % $RegistrosAMostrar;
// si hay residuo usamos funcion floor para que me
// devuelva la parte entera, SIN REDONDEAR, y le sumamos
// una unidad para obtener la ultima pagina
        if ($Res > 0)
            $PagUlt = floor($PagUlt) + 1;

//desplazamiento
        echo "<button onclick=\"Pagina('1','false','todo')\">Primero</button> ";
        if ($PagAct > 1)
            echo "<button onclick=\"Pagina('$PagAnt','false','todo')\">Anterior</button> ";
        echo "<strong>Pagina " . $PagAct . "/" . $PagUlt . "</strong>";
        if ($PagAct < $PagUlt) {
            echo "<button onclick=\"Pagina('$PagSig','false','todo')\">Siguiente</button> ";
        }

        if ($PagUlt == 0) {
            echo "<button>Ultimo</button>";
        } else {
            echo "<button onclick=\"Pagina('$PagUlt','false','todo')\">Ultimo </button>";
        }
    }
}   
}else{
    echo ("No existe sesi�n");
}
    ?>
