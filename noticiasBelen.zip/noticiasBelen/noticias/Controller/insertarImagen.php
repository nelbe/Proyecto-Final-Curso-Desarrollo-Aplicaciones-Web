<?php
  require_once '../Model/Imagen.php';

  // sube la imagen al servidor
  $idNoticia = $_POST['idNoticia'];
  for($i = 0; $i<count($_FILES['imagen']['name']); $i++ ){
      
    move_uploaded_file($_FILES["imagen"]["tmp_name"][$i], "../images/" . $_FILES["imagen"]["name"][$i]);
    $imagenAux = new Imagen("", $idNoticia, $_FILES["imagen"]["name"][$i]);
    $imagenAux->insert();
     
  } 
  header("Location: ../administrarGaleria.php?id=$idNoticia");
  
 