<?php
  require_once '../Model/Noticia.php';
  $noticiaAux = new Noticia($_GET['id']);
  $noticiaAux->delete();
  header("Location: ../panelAdmin.php");