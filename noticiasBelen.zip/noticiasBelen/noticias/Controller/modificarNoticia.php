<?php
  require_once '../Model/Noticia.php';
  
  /*if(empty($_FILES['imagen']['name'])){//SI LA IMAGEN ESTA VACIA
    $imagen = $_POST['imagenVacia'];
  }else{
     move_uploaded_file($_FILES["imagen"]["tmp_name"], "../images/" . $_FILES["imagen"]["name"]);
     $imagen = $_FILES["imagen"]["name"];
  }*/
  if(empty($_POST['fechaModificacion'])){
      $fecha = time();
      $fecha2 = date("d/m/Y",$fecha);
  }else{
      $fecha2 = $_POST['fechaModificacion'];
  }
  $noticiaAux = new Noticia($_POST['idNoticia'],$_POST['idUsuario'], $_POST['titulo'],$_POST['fechaPublicacion'], $_POST['descripcion'], "",$fecha2,$_POST['video'],"");
  //var_dump($noticiaAux);
  //die();
  $noticiaAux->update();
  header("Location: ../panelAdmin.php");

  
  