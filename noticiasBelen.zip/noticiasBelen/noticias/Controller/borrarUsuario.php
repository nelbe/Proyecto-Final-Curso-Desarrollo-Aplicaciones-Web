<?php
  require_once '../Model/Usuario.php';
  $noticiaAux = new Usuario($_GET['id']);
  $noticiaAux->deleteUsuario();