<?php
  require_once '../Model/Comentario.php';
  $idNoticia = $_POST['idNoticia'];
  $usuarioAux = new Comentario($_POST['idComentario'], $_POST['usuario'], $_POST['fecha'], $_POST['comentario'], $_POST['idNoticia'], $_POST['idUsuarioFacebook'], $_POST['email']);
  
  $usuarioAux->update();
  header("Location: ../leerMas/index.php?id=$idNoticia");

  
  