<?php
  require_once '../Model/Usuario.php';

  $usuarioAux = new Usuario("", $_POST['email'], md5($_POST['password']), $_POST['permiso'], $_POST['nombre']);
  
  //var_dump($usuarioAux);
  //die ();
  
  $usuarioAux->insert();
  header("Location: ../nuevoUsuario/nuevoUsuarioAdmin.php");