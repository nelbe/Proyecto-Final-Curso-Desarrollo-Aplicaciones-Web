<?php

require_once '../Model/Comentario.php';

// inserta el comentario en la base de datos
$comentAux = new Comentario("",$_POST['usuario'],"", $_POST['comentario'], $_POST['idNoticia'],$_POST['idUsuarioFacebook'],$_POST['email']);
$comentAux->insert();
header("Location: ../leerMas/index.php?id=".$_POST['idNoticia']);
