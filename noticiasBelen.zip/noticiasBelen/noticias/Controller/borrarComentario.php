<?php
require_once '../Model/Comentario.php';
$idNoticia = $_GET['idNoticia'];
$noticiaAux = new Comentario($_GET['id'],"","","","","","");
$noticiaAux->deleteComentario();
header("Location: ../leerMas/index.php?id=$idNoticia");