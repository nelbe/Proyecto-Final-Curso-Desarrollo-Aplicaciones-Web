<?php
  require_once '../Model/Usuario.php';
  
  $permiso;
  $permiso = $_POST['permiso'];
  
  if ($permiso == administrador){
      $permiso = administrador;
  }else{
      $permiso = editor;
  }
  
  $usuarioAux = new Usuario($_POST['id'], $_POST['email'], md5($_POST['password']), $permiso, $_POST['nombre']);
  
  $usuarioAux->update();
  header("Location: ../nuevoUsuario/nuevoUsuarioAdmin.php");

  
  