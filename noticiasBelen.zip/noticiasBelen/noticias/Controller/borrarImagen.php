<?php
require_once '../Model/Imagen.php';
$idImagen = $_GET['idImagen'];
$idImagenes = explode(",", $idImagen);
//var_dump($idImagenes);
//Usamos el count para recorrer los elementos de un array
for($i = 0; $i<(count($idImagenes)-1); $i++){
    $noticiaAux = new Imagen($idImagenes[$i],"","");
    $noticiaAux->deleteImagen();
}
die();
header("Location: ../leerMas/index.php?id=$idNoticia");