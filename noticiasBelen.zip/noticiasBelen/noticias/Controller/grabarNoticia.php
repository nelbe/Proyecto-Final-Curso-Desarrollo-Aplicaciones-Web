<?php
  require_once '../Model/Noticia.php';
  require_once '../Model/BlogDB.php';
  require_once '../Model/Imagen.php';

  // sube la imagen al servidor
  $idNoticia = null;
  $fecha = time();

  $fecha2 = date("d/m/Y",$fecha);
  
  for($i = 0; $i<count($_FILES['imagen']['name']); $i++ ){
     //Para mover las imágenes al directorio de nuestro servidor  
     move_uploaded_file($_FILES["imagen"]["tmp_name"][$i], "../images/" . $_FILES["imagen"]["name"][$i]);
  }
  // inserta la noticia en la base de datos
  $noticiaAux = new Noticia("",$_POST['idUsuario'], $_POST['titulo'],$fecha2, $_POST['descripcion'], $_FILES["imagen"]["name"][0],"",$_POST['video'],"");
   
  $noticiaAux->insert();

      //Consulta a útima noticia añadida para sacar idNoticia
   $data['noticias'] = Noticia::getUltimaNoticia();
    foreach ($data['noticias'] as $noticia) { //Obtiene num visitias de la noticia actual
        $idNoticia = $noticia->getIdNoticia();
    }
    //Haces un objeto por cada imagen que haya y una inserción por cada imagen que haya
    for($u = 0; $u<count($_FILES['imagen']['name']); $u++ ){//Insertamos imagen tantas como hayan
        $imagenAux = new Imagen("", $idNoticia, $_FILES["imagen"]["name"][$u]);
        $imagenAux->insert();
        
    }

  header("Location: ../panelAdmin.php");
  
 