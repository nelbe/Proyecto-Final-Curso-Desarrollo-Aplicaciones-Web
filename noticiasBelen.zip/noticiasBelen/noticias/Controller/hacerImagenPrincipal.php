<?php
  require_once '../Model/Noticia.php';
  
  $noticiaAux = new Noticia($_GET['idNoticia'], "", "", "", "", $_GET['nombreImagen'],"","","");
  //var_dump($noticiaAux);
  //die();
  $noticiaAux->updateImagen();
  header("Location: ../panelAdmin.php");

  
  