<?php
require_once '../Model/Usuario.php';
session_start();
if (isset($_SESSION['login']['login'])) {


    if ($_SESSION['login']['login']) {
        ?>
        <!DOCTYPE html>
        <html>
            <head>
                <meta charset="UTF-8">
                <title></title>
                <link rel="shortcut icon" href="../css/imagenes/favicon.png">
                <link href="../css/form.css" rel="stylesheet" type="text/css"/>
            </head>

            <body>
                <?php
                $data['usuarios'] = Usuario::getUsuarioById($_GET['id']);
                foreach ($data['usuarios'] as $usuario) {
                    ?>
                    <div id="centro">
                        <form action="../Controller/modificarUsuario.php"  enctype="multipart/form-data" method="POST" class="formNuevoUsuario">
                            <h3>Nombre</h3>
                            <input class="anchoInput" type="text" size="40" name="nombre" value="<?= $usuario->getNombre() ?>">
                            <h3>Email</h3>
                            <input class="anchoInput" type="text" size="40" name="email" value="<?= $usuario->getEmail() ?>">
                            <h3>Cotraseña</h3>
                            <input class="anchoInput" type="password" size="40" name="password" value="<?= $usuario->getPassword() ?>">
                            <h3>Permiso</h3>
                            <select name="permiso" selected="<?= $usuario->getPermiso() ?>">
                                <?php // Este if saca en el select el permiso que tiene
                                      //el usuario, como solo hay dos tipos de persmisos
                                      //se hace de esta forma.
                                
                                if ($usuario->getPermiso()== 'editor'){
                                ?>    
                                    <option value="editor">Editor</option>
                                    <option value="administrador">Administrador</option>
                                <?php
                                }else{
                                ?>
                                    <option value="administrador">Administrador</option>
                                    <option value="editor">Editor</option>
                                <?php    
                                }
                                ?>
                            </select>
                            <hr>
                            <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                            <input type="submit" value="Aceptar" class="aceptar">
                            <a href="../nuevoUsuario/nuevoUsuarioAdmin.php"><button>Cancelar</button></a>
                        </form>
                    </div>    
                    <?php
                }
                ?>	

            </body>
        </html>
        <?php
    }//Fin comprobacion de login
    else {//Si no estas logueado
    }
} else {// Si no existe la variable de session login
    header('Location: ../login.php');
}
?>