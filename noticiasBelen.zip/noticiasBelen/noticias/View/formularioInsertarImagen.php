<?php
session_start();
if(isset($_SESSION['login']['login'])){
    

    if($_SESSION['login']['login']){
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="shortcut icon" href="../css/imagenes/favicon.png">
    <link href="../css/form.css" rel="stylesheet" type="text/css"/>
    <!--<script src = "https://cdn.tinymce.com/4/tinymce.min.js"> </script>-->
    <script src="../js/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="../js/jquery-1.12.1.min.js" type="text/javascript"></script>
  </head>
  
  <script> 
   tinymce.init({
    selector: '#myTextArea', 
    plugin: 'a_tinymce_plugin',
    a_plugin_option: true,
    a_configuration_option: 400
  });
  </script>
  <script>
  $(function(){
      //Limpiar vista previa
      $("#imagen").on("change",function(){
          $("#vistaPrevia").html("");
          var archivos = document.getElementById('imagen').files;
          var navegador = window.URL || window.webkitURL;
          //Recorrer los archivos
          for(i = 0; i < archivos.length; i++){
              console.log("hola");
              var type = archivos[i].type;
              
              if(type !== "image/jpeg" && type !== "image/jpg" && type !== "image/png" && type !== "image/gif"){
                  $("#vistaPrevia").append("El fichero introducido no es del tipo de imagen permitido");
              }else{
                  var objetoUrl = navegador.createObjectURL(archivos[i]);
                  $("#vistaPrevia").append("<img src="+objetoUrl+" width='100'>");
              }
          }
          
      });
  });
  </script>
  
  <body>
      <div id="centro">
          <form action="../Controller/insertarImagen.php" id="formularioInsertarImagen" enctype="multipart/form-data" method="POST">
            
          <h3>Imagenes galeria</h3>
          <!--<input id="imagen" class="anchoInput" type="files" multiple="true" name="imagenes[]" />-->
          <input class="anchoInput" type="file" id="imagen" name="imagen[]" multiple="">
          <input type="hidden" name="idNoticia" value="<?= $_GET['idNoticia'];?>"
          <hr>
          <br>
          <div id="vistaPrevia">
              
          </div><input class="aceptar" type="submit" value="Aceptar">
          <a class="cancelar" href="../administrarGaleria.php?id=<?= $_GET['idNoticia'];?> ">Cancelar</a>
        </form>
          
      </div>
      
  </body>
</html>
<?php
}//Fin comprobacion de login
    else{//Si no estas logueado
        echo("<h1>Debes loguearte para visualizar esta página</h1>");
    }
}else{// Si no existe la variable de session login
    header('Location: ../login.php');
}
?>