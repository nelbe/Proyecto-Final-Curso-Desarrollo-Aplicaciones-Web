<?php
session_start();
if (isset($_SESSION['login']['login'])) {


    if ($_SESSION['login']['login']) {
        ?>
        <!DOCTYPE html>
        <html>
            <head>
                <meta charset="UTF-8">
                <title></title>
                <link rel="shortcut icon" href="../css/imagenes/favicon.png">
                <link href="../css/form.css" rel="stylesheet" type="text/css"/>
            </head>

            <body>
                <div id="centro">
                    <form action="../Controller/grabarUsuario.php" method="POST" class="formNuevoUsuario">
                        <h3>Nombre</h3>
                        <input class="anchoInput" type="text" size="40" name="nombre">
                        <h3>Email</h3>
                        <input class="anchoInput" type="text" size="40" name="email" pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" required>
                        <h3>Cotraseña</h3>
                        <input class="anchoInput" type="password" size="40" name="password">
                        <h3>Permiso</h3>
                        <select name="permiso">
                            <option value="editor">Editor</option>
                            <option value="administrador">Administrador</option>
                        </select>
                        <hr>
                        <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                        <input class="aceptar" type="submit" value="Aceptar">
                        <a href="../nuevoUsuario/nuevoUsuarioAdmin.php" class="cancelar">Cancelar</a>
                        
                    </form>

                </div>
            </body>
        </html>
        <?php
    }//Fin comprobacion de login
    else {//Si no estas logueado
        echo("<h1>Debes loguearte para visualizar esta página</h1>");
    }
} else {// Si no existe la variable de session login
    header('Location: ../login.php');
}
?>