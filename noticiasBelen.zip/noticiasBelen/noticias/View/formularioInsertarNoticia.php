<?php
session_start();
if(isset($_SESSION['login']['login'])){
    

    if($_SESSION['login']['login']){
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="shortcut icon" href="../css/imagenes/favicon.png">
    <link href="../css/form.css" rel="stylesheet" type="text/css"/>
    <!--<script src = "https://cdn.tinymce.com/4/tinymce.min.js"> </script>-->
    <script src="../js/tinymce/tinymce.min.js" type="text/javascript"></script>
  </head>
  
  <script> 
   tinymce.init({
    selector: '#myTextArea',  // change this value according to your HTML
    plugin: 'a_tinymce_plugin',
    a_plugin_option: true,
    a_configuration_option: 400
  });
  </script>
  
  <body>
      <div id="centro">
          <form action="../Controller/grabarNoticia.php"  enctype="multipart/form-data" method="POST" class="formNuevoUsuario">
            <div>
                <h1>Nueva Noticia</h1>
            </div>    
          <h3>Título</h3>
          <input class="anchoInput" type="text" size="40" name="titulo">
          <h3>Descripción</h3>
          <textarea  id="myTextArea" name="descripcion">Escriba aqui su noticia</textarea>
          <h3>Imagen</h3>
          <!--<input id="imagen" class="anchoInput" type="files" multiple="true" name="imagenes[]" />-->
          <input class="anchoInput" type="file" id="imagen" name="imagen[]" multiple="">
          <h3>V�deo</h3>
          <input class="anchoInput" type="text" id="video" name="video">
          <input type="hidden" name="idUsuario" value="<?= $_SESSION['login']['idUsuario']?>"
          <hr>
          <input class="aceptar" type="submit" value="Aceptar">
          <a class="cancelar" href="../panelAdmin.php">Cancelar</a>
        </form>
          
      </div>
  </body>
</html>
<?php
}//Fin comprobacion de login
    else{//Si no estas logueado
        echo("<h1>Debes loguearte para visualizar esta página</h1>");
    }
}else{// Si no existe la variable de session login
    header('Location: ../login.php');
}
?>