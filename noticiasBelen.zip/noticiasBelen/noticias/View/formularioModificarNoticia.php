<?php
require_once '../Model/Noticia.php';
session_start();
if(isset($_SESSION['login']['login'])){
    

    if($_SESSION['login']['login']){
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="shortcut icon" href="../css/imagenes/favicon.png">
        <link href="../css/form.css" rel="stylesheet" type="text/css"/>
        <script src="../js/tinymce/tinymce.min.js" type="text/javascript"></script>
</script>
    </head>
    
    <script> 
        tinymce.init({
            selector: '#myTextArea',  
            plugin: 'a_tinymce_plugin',
            a_plugin_option: true,
            a_configuration_option: 400
        });
    </script>
    
    <body>
        <?php
        $data['noticias'] = Noticia::getNoticiaById($_GET['id']);
        foreach ($data['noticias'] as $noticia) {
            ?>
            <div id="centro">
                <form action="../Controller/modificarNoticia.php"  enctype="multipart/form-data" method="POST" class="formNuevoUsuario">
                    <h3>Título</h3>
                    <input class="anchoInput" type="text" size="40" name="titulo" value="<?= $noticia->getTitulo() ?>">
                    <h3>Descripción</h3>
                    <textarea  id="myTextArea" name="descripcion"><?= $noticia->getDescripcion() ?></textarea>
                    <h3>Fecha Modificación</h3>
                    <input class="anchoInput" type="date" name="fechaModificacion">
                    <h3>Vídeo</h3>
                    <input class="anchoInput" type="text" id="video" name="video" value='<?=$noticia->getVideo()?>'>
                    <input type="hidden" name="fechaPublicacion" value="<?= $noticia->getFecha()?>">
                    <input type="hidden" name="idNoticia" value="<?= $_GET['id']?>">
                    <input type="hidden" name="idUsuario" value="<?= $noticia->getIdUsuario() ?>">
                    <input class="aceptar" type="submit" value="Aceptar"> 
                    <a class="cancelar" href="../panelAdmin.php">Cancelar</a>
                    <script type=�?text/javascript�?>
                        CKEDITOR.replace (“editor1�?);
                    </script>
                </form>
            </div>    
            <?php
        }
        ?>	

    </body>
</html>
<?php
}//Fin comprobacion de login
    else{//Si no estas logueado
    }
}else{// Si no existe la variable de session login
    header('Location: ../login.php');

}
?>