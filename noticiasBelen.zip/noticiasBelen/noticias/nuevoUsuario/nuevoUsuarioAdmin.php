<?php
require_once '../Model/Noticia.php';
session_start();
if (isset($_SESSION['login']['login'])) {


    if ($_SESSION['login']['login']) {
        if ($_SESSION['login']['permiso'] == 'administrador') {
            ?>
            <!DOCTYPE HTML>

            <html>
                <head>
                    <title>Nuevo Usuario | Aceites Málaga</title>
                    <meta http-equiv="content-type" content="text/html; charset=utf-8" />

                    <meta name="description" content="" />
                    <meta name="keywords" content="" />
                    <!--<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>-->
                    <link rel="shortcut icon" href="css/imagenes/favicon.png">
                    <!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
                    <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->
                    <script src="../js/jquery-1.12.1.min.js" type="text/javascript"></script>
                    <script src="../js/skel.min.js"></script>
                    <script src="../js/skel-panels.min.js"></script>
                    <script src="../js/init.js"></script>
                    <script src="paginadorUsuarioAdmin.js" type="text/javascript"></script>
                    <script src="../js/borrarUsurario.js" type="text/javascript"></script>
                    <link href="../js/jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
                    <script src="../js/jquery-ui-1.11.4.custom/jquery-ui.min.js" type="text/javascript"></script>
                    <script src="../js/busquedaUsuarios.js" type="text/javascript"></script>
                    <link href="../fontAwesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
                    <link href="../fontAwesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
                    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">-->
                    <noscript
                        <link rel="stylesheet" href="css/skel-noscript.css" />
                    <link rel="stylesheet" href="css/style.css" />
                    <link rel="stylesheet" href="css/style-desktop.css" />
                    </noscript>    
                    <!--<link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css" />-->

                    <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
                    <!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
                    <style>
                        #nav{
                            position:absolute;
                            width: 100%;
                            top: 10px;
                        }

                        #nav > ul > li
                        {
                            float: left;
                        }

                        #nav > ul > li:last-child
                        {
                            padding-right: 0;
                        }

                        #nav > ul > li > a,
                        #nav > ul > li > span
                        {
                            display: block;
                            margin-left: 0.7em;
                            padding: 0.80em 1.2em;
                            letter-spacing: 0.06em;
                            text-decoration: none;
                            font-size: 1em;
                            outline: 0;
                            color: white;
                            font-family: "Helvetica";
                            font-weight: bold;
                            border-top: 1px solid #3B8054; 
                        }

                        #nav li.active a
                        {
                            background: #1A6B38;
                            border-radius: 5px;
                            color: white;
                            font-family: "Helvetica";
                            font-weight: bold;
                        }

                        #nav > ul > li > ul
                        {
                            display: none;
                        }
                    </style>
                </head>
                <body>

                    <!-- Header -->
                    <div id="header" class="headerAdmin">
                        <div class="container">
                            <nav id="nav">
                                <ul>
                                    <li><a href="../panelAdmin.php">NOTICIAS</a></li>
                                    <li><a href="../nuevoUsuario/nuevoUsuarioAdmin.php">USUARIOS</a></li>
                                    <li><a href="../logout.php">SALIR</a></li>
                                </ul>
                            </nav>
                            <div id="tituloPanel">
                                <h1>PANEL DE ADMINISTRACIÓN</h1>
                            </div>

                        </div>
                    </div>
                    <!-- Header -->


                    <div id="featured">
                        <div class="container">
                            <h2 class="tituloAdministracion">Gestión de usuarios</h2>
                            <div class="row" id="divPanel">
                                <a href="../View/formularioInsertarUsuario.php" id="nuevaNoticia"/>Añadir Usuario&nbsp;✚</a>
                                <a id="busqueda"/>Búsqueda <i class="fa fa-search" aria-hidden="true"></i></a>
                                <div id="contenedorTabla">
                                    <?php include('paginadorUsuarioAdmin.php') ?>
                                </div> 
                            </div>          
                        </div>
                    </div>


                    <div id="dialogoBorrarUser" title="Borrar Usuario">¿Desea borrar este usuario?</div>
                    <div id="btnBuscar" title="Nueva Busqueda">¿Buscar usuarios por <strong>Nombre</strong>?</div>
                    <form id="formBuscarNombre">
                        Nombre: <input id="inputNombre" type="text" name="titulo">
                    </form>

                </body>
            </html>
            <?php
        }//Fin comprobaci�n de permiso
        else {
            echo "Solo tiene acceso el administrador";
        }
    }//Fin comprobacion de login
    else {//Si no estas logueado
        echo("<h1>Debes loguearte para visualizar esta página</h1>");
    }
} else {// Si no existe la variable de session login
    header('Location: ../login.php');
}
?>