
<?php

require_once '../Model/BlogDB.php';
$connection = BlogDB::connectDB();

if (isset($_GET["nombre"])) {
    $nombre = $_GET["nombre"];
}


$RegistrosAMostrar=4;

//estos valores los recibo por GET
if(isset($_GET['pag'])){
	$RegistrosAEmpezar=($_GET['pag']-1)*$RegistrosAMostrar;
	$PagAct=$_GET['pag'];
//caso contrario los iniciamos
}else{
	$RegistrosAEmpezar=0;
	$PagAct=1;
	
}

if (isset($nombre)) {
 
    $Resultado = $connection->query("SELECT * FROM usuarios WHERE nombre LIKE '$nombre%' ORDER BY idUsuario DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");

}else{

    $Resultado= $connection->query("SELECT * FROM usuarios ORDER BY idUsuario DESC LIMIT $RegistrosAEmpezar, $RegistrosAMostrar");
}    
 ?>
<table id="tableAdmin">  
    
<?php                        
while($MostrarFila=$Resultado->fetchObject()){
?>
    <tr id="usuariosPanelAdmin<?= $MostrarFila->idUsuario ?>">
        <td id="fechaAdmin"><?= $MostrarFila->nombre ?></td>
        <td id="fechaAdmin"><?= $MostrarFila->email ?></td>
        <td id="tituloAdmin"><?= $MostrarFila->permiso ?></td>
        <td class="iconosFa" ><a href="../View/formularioModificarUsuario.php?id=<?= $MostrarFila->idUsuario?>"><i class="fa fa-pencil"></i></a></td>
        <td class="iconosFa"><i id="borrar" class="fa fa-close" name="<?= $MostrarFila->idUsuario ?>"></i></td>
    </tr>
<?php    	
}
?>
</table>
<?php
//******--------determinar las p�ginas---------******//

if (isset($nombre)){
        $consultaNumRegistro=$connection->query("SELECT count(*)AS Registros FROM usuarios WHERE nombre='$nombre'");
    while($MostrarFila=$consultaNumRegistro->fetchObject()){
       $NroRegistros= $MostrarFila->Registros;
    }

    $PagAnt=$PagAct-1;
    $PagSig=$PagAct+1;
    $PagUlt=$NroRegistros/$RegistrosAMostrar;

    //verificamos residuo para ver si llevar� decimales
    $Res=$NroRegistros%$RegistrosAMostrar;
    // si hay residuo usamos funcion floor para que me
    // devuelva la parte entera, SIN REDONDEAR, y le sumamos
    // una unidad para obtener la ultima pagina
    if($Res>0) $PagUlt=floor($PagUlt)+1;

    //desplazamiento
    echo "<button onclick=\"Pagina('1','$nombre','nombre')\">Primero</button> ";
    if($PagAct>1) echo "<button onclick=\"Pagina('$PagAnt','$nombre','nombre')\">Anterior</button> ";
    echo "<strong>Pagina ".$PagAct."/".$PagUlt."</strong>";
    if($PagAct<$PagUlt){
        echo "<button onclick=\"Pagina('$PagSig','$nombre','nombre')\">Siguiente</button> ";
    }    

    if ($PagUlt==0){
        echo "<button>Ultimo</button>";
    }else{
        echo "<button onclick=\"Pagina('$PagUlt','$nombre','nombre')\">Ultimo </button>";
    }
}else{

    $consultaNumRegistro=$connection->query("SELECT count(*)AS Registros FROM usuarios");
    while($MostrarFila=$consultaNumRegistro->fetchObject()){
       $NroRegistros= $MostrarFila->Registros;
    }

    $PagAnt=$PagAct-1;
    $PagSig=$PagAct+1;
    $PagUlt=$NroRegistros/$RegistrosAMostrar;

    //verificamos residuo para ver si llevar� decimales
    $Res=$NroRegistros%$RegistrosAMostrar;
    // si hay residuo usamos funcion floor para que me
    // devuelva la parte entera, SIN REDONDEAR, y le sumamos
    // una unidad para obtener la ultima pagina
    if($Res>0) $PagUlt=floor($PagUlt)+1;

    //desplazamiento
    echo "<button onclick=\"Pagina('1','false','todo')\">Primero</button> ";
    if($PagAct>1) echo "<button onclick=\"Pagina('$PagAnt','false','todo')\">Anterior</button> ";
    echo "<strong>Pagina ".$PagAct."/".$PagUlt."</strong>";
    if($PagAct<$PagUlt){
        echo "<button onclick=\"Pagina('$PagSig','false','todo')\">Siguiente</button> ";
    }    

    if ($PagUlt==0){
        echo "<button>Ultimo</button>";
    }else{
        echo "<button onclick=\"Pagina('$PagUlt','false','todo')\">Ultimo </button>";
    }
}    
?>
