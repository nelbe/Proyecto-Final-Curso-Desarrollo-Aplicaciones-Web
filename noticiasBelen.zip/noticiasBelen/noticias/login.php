<?php 
require_once 'Model/Login.php'; 
session_start();
if(!isset($_SESSION['login'])){//Si no existe la session login la inicializamos a null
  $_SESSION['login']= array("login"=>null,"idUsuario" =>null,"email"=>null,"permiso"=>null);
}
?>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
        <link rel="shortcut icon" href="css/imagenes/favicon.png">
        <link href="css/formularioLogin.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<?php


                            


if(isset($_POST['email'])){
$data['usuarios'] = Login::getUsuarioByEmail($_POST['email']);
foreach ($data['usuarios'] as $usuario){ 
    if(md5($_POST['password']) == $usuario->getPassword()){
      $_SESSION['login']['login'] = true;
      $_SESSION['login']['idUsuario'] = $usuario->getIdUsuario();
      $_SESSION['login']['email'] = $usuario->getEmail();
      $_SESSION['login']['permiso'] = $usuario->getPermiso();
      
      }else{
        $_SESSION['login']['login'] = false;
      }
}
    
if($_SESSION['login']['login']== true){
 ?>
        <meta http-equiv="Refresh" content="0;url=panelAdmin.php">
        <?php
}else{


  ?>

  <div class="wrapper">
  <div class="container">
    <h1>Panel Administración</h1>
    <p style="color:red;">Datos introducidos incorrectos</p>
    <form action="login.php" method="post">
      <input type="text" placeholder="Email" name="email" >
      <input type="password" placeholder="Contraseña" name="password">
      <button type="submit" id="login-button">Login</button>
    </form>
  </div>
  
  <ul class="bg-bubbles">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
</div>
  
  <?php
    }
  }else{
  ?>
    <div class="wrapper">
  <div class="container">
    <h1>Panel Administración</h1>
    <form action="login.php" method="post">
      <input type="text" placeholder="Email" name="email">
      <input type="password" placeholder="Contraseña" name="password">
      <button type="submit" id="login-button">Login</button>
    </form>
  </div>
  
  <ul class="bg-bubbles">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
</div>
    
  <?php
    }
?>


</body>
</html>