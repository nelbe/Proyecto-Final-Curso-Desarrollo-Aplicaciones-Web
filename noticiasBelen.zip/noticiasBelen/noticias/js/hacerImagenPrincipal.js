$(document).ready(function () {
    var idImagen;
    var idNoticia;
    var nombreImagen;
    var contador = 0;
    
    $("#dialogoHacerPrinciapal").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "Aceptar": function () {
                //console.log(idImagen);
                $.get("Controller/hacerImagenPrincipal.php?idNoticia=" + idNoticia+"&nombreImagen="+nombreImagen, function () {
                    $.notify("La imagen seleccionada ha sido establecida como principal","success");
                });
                contador = 0;
                $(this).dialog("close");
            },
            "Cancelar": function () {
                $(this).dialog("close");
            }
        }
    });
    
    $(document).on("click", "#hacerPrincipal", function () {
        $("#contenedorTabla img[name=" + "selected" + "]").each(function () {
            nombreImagen = $(this).attr("file");
            idNoticia = $(this).attr("idNoticia");
            contador++;
            
        });
        if(contador > 1){
            $.notify("Para hacer principal la imagen solo puedes seleccionar una ");
            contador = 0;
        }else{
            if(contador == 1){
                 $("#dialogoHacerPrinciapal").dialog("open");
            }else{
                if(contador == 0){
                    $.notify("Debes seleccionar un elemento como minimo");
                    contador = 0;
                }
            }
        }
        
    });
});