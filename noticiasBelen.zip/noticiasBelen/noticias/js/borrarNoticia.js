$(document).ready(function(){
    var idNoticia;
    //VENTANA DIALOGO BORRAR
    $("#dialogoBorrar").dialog({
        autoOpen :false,
        resizable :false,
        modal : true,
        buttons:{
            "Borrar": function(){
                $.get("Controller/borrarNoticia.php?id=" + idNoticia,function(){
                    $("#noticiasPanelAdmin" + idNoticia).fadeOut(1000);
                });
                $(this).dialog( "close" );
            },
            "Cancelar": function(){
                $(this).dialog( "close" );
            }
        }
    });
    //BORRAR
    $(document).on("click","#borrar",function(){
        idNoticia = $(this).attr("name");
        $("#dialogoBorrar").dialog("open");
        console.log("El id es: " + idNoticia);
    })
});