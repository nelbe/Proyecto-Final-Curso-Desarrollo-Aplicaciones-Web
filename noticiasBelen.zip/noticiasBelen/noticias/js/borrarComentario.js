$(document).ready(function(){
    var idComentario;
    //VENTANA DIALOGO BORRAR
    $("#dialogoBorrar").dialog({
        autoOpen :false,
        resizable :false,
        modal : true,
        buttons:{
            "Borrar": function(){
                $.get("Controller/borrarComentario.php?id=" + idComentario,function(){
                    $("#comentarioPanelAdmin" + idComentario).fadeOut(1000);
                    
                })
                $(this).dialog( "close" );
            },
            "Cancelar": function(){
                $(this).dialog( "close" );
            }
        }
    });
    //BORRAR
    $(document).on("click","#borrar",function(){
        idComentario = $(this).attr("name");
        $("#dialogoBorrar").dialog("open");
    })
});