$(document).ready(function () {
    var idImagen;
    var contador = 0;
    //VENTANA DIALOGO BORRAR
    $("#dialogoBorrar").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "Borrar": function () {
                //console.log(idImagen);
                $.get("Controller/borrarImagen.php?idImagen=" + idImagen, function () {
                    $("#contenedorTabla img[name=" + "selected" + "]").fadeOut(1000,function(){
                        $(this).remove();
                    });

                });
                
                $(this).dialog("close");
            },
            "Cancelar": function () {
                $(this).dialog("close");
            }
        }
    });
    //BORRAR
    $(document).on("click", "#borrarImagen", function () {
        $("#contenedorTabla img[name=" + "selected" + "]").each(function () {
            if(contador == 0){
                idImagen = $(this).attr("value")+",";
                contador++;
            }else{
                idImagen += $(this).attr("value")+",";
            }
            
        });
        contador = 0;
        $("#dialogoBorrar").dialog("open");
    });
    $(document).on("click", "#contenedorTabla img", function () {
        if ($(this).attr("name") !== "selected") {
            $(this).attr("name", "selected");
            $(this).css("border", "5px solid black");
        } else {
            $(this).attr("name", "unselected");
            $(this).removeAttr("style");
        }



    });
});