$(document).ready(function(){
    var idUsuario;
    //VENTANA DIALOGO BORRAR
    $("#dialogoBorrarUser").dialog({
        autoOpen :false,
        resizable :false,
        modal : true,
        buttons:{
            "Borrar": function(){
                $.get("../Controller/borrarUsuario.php?id=" + idUsuario,function(){
                    $("#usuariosPanelAdmin" + idUsuario).fadeOut(1000);
                    
                })
                $(this).dialog( "close" );
            },
            "Cancelar": function(){
                $(this).dialog( "close" );
            }
        }
    });
    //BORRAR
    $(document).on("click","#borrar",function(){
        idUsuario = $(this).attr("name");
        $("#dialogoBorrarUser").dialog("open");
    })
});