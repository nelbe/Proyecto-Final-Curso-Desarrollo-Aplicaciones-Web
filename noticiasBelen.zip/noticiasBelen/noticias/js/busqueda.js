$(document).ready(function () {

    function objetoAjax() {
        var xmlhttp = false;
        try {
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (E) {
                xmlhttp = false;
            }
        }

        if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
            xmlhttp = new XMLHttpRequest();
        }
        return xmlhttp;
    }
    
    var fecha;
    var titulo;
    
    $("#formBuscarTitulo").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "enviar": function () {
                titulo = document.getElementById("inputTitulo").value;
                console.log(titulo);
                
                divContenido = document.getElementById('contenedorTabla');
                ajax = objetoAjax();
               
                ajax.open("GET", "paginadorAdmin.php?titulo=" + titulo);

                ajax.onreadystatechange = function () {
                    if (ajax.readyState == 4) {
                       divContenido.innerHTML = ajax.responseText; 
                    }
                }
                ajax.send(null);
                $(this).dialog("close");   
            }
        }
    });

    $("#formBuscarFecha").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "enviar": function () {
                fecha = document.getElementById("inputFecha").value;
                console.log(fecha);
                
                divContenido = document.getElementById('contenedorTabla');
                ajax = objetoAjax();
               
                ajax.open("GET", "paginadorAdmin.php?fecha=" + fecha);

                ajax.onreadystatechange = function () {
                    if (ajax.readyState == 4) {
                       divContenido.innerHTML = ajax.responseText; 
                    }
                }
                ajax.send(null);
                $(this).dialog("close");

            }
        }
    });

    $("#btnBuscar").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "Fecha": function () {
                $("#formBuscarFecha").dialog("open");
                $(this).dialog("close");
            },
            "Titulo": function () {
                $("#formBuscarTitulo").dialog("open");
                $(this).dialog("close");
            },
            "Cancelar": function () {
                $(this).dialog("close");
            }
        }
    });

    $(document).on("click", "#busqueda", function () {
        $("#btnBuscar").dialog("open");
    })
});

