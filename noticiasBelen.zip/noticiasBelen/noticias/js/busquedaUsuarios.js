$(document).ready(function () {

    function objetoAjax() {
        var xmlhttp = false;
        try {
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (E) {
                xmlhttp = false;
            }
        }

        if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
            xmlhttp = new XMLHttpRequest();
        }
        return xmlhttp;
    }

    var nombre;
    
    $("#formBuscarNombre").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "enviar": function () {
                nombre = document.getElementById("inputNombre").value;
                console.log(nombre);
                
                divContenido = document.getElementById('contenedorTabla');
                ajax = objetoAjax();
               
                ajax.open("GET", "paginadorUsuarioAdmin.php?nombre=" + nombre);

                ajax.onreadystatechange = function () {
                    if (ajax.readyState == 4) {
                       divContenido.innerHTML = ajax.responseText; 
                    }
                }
                ajax.send(null);
                $(this).dialog("close");   
            }
        }
    });


    $("#btnBuscar").dialog({
        autoOpen: false,
        resizable: false,
        modal: true,
        buttons: {
            "Aceptar": function () {
                $("#formBuscarNombre").dialog("open");
                $(this).dialog("close");
            },
            "Cancelar": function () {
                $(this).dialog("close");
            }
        }
    });

    $(document).on("click", "#busqueda", function () {
        $("#btnBuscar").dialog("open");
    })
});

