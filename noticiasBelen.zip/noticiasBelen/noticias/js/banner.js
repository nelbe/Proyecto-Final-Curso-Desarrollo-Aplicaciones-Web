$(document).ready(function () {
   $(document).ready(function(){	
      var sudoSlider = $("#slider").sudoSlider({ 
         effect: "fade",
         auto:true,
         resumePause: 10000
      });
   });
});