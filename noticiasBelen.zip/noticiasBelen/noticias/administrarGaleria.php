<?php
require_once 'Model/Imagen.php';
session_start();
if (isset($_SESSION['login']['login'])) {


    if ($_SESSION['login']['login']) {
        ?>
        <!DOCTYPE HTML>
        <html>
            <head>
                <title>Noticias | Aceites Málaga</title>
                <meta http-equiv="content-type" content="text/html; charset=utf-8" />

                <meta name="description" content="" />
                <meta name="keywords" content="" />
                <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
                <link rel="shortcut icon" href="css/imagenes/favicon.png">
                <!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
                <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/skel-panels.min.js"></script>
                <script src="js/init.js"></script>
                <script src="paginadorAdminComentario.js" type="text/javascript"></script>
                <script src="js/borrarImagen.js" type="text/javascript"></script>
                <script src="js/hacerImagenPrincipal.js" type="text/javascript"></script>
                <script src="js/notify.min.js" type="text/javascript"></script>
                <link href="js/jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
                <script src="js/jquery-ui-1.11.4.custom/jquery-ui.min.js" type="text/javascript"></script>
                <link href="fontAwesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
                <link href="fontAwesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
                <noscript>
                <link rel="stylesheet" href="css/skel-noscript.css" />
                <link rel="stylesheet" href="css/style.css" />
                <link rel="stylesheet" href="css/style-desktop.css" />
                <!--<link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css" />-->
                </noscript>
                <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
                <!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
                <style>
                    #nav{
                        position:absolute;
                        width: 100%;
                        top: 10px;
                    }

                    #nav > ul > li
                    {
                        float: left;
                    }

                    #nav > ul > li:last-child
                    {
                        padding-right: 0;
                    }

                    #nav > ul > li > a,
                    #nav > ul > li > span
                    {
                        display: block;
                        margin-left: 0.7em;
                        padding: 0.80em 1.2em;
                        letter-spacing: 0.06em;
                        text-decoration: none;
                        font-size: 1em;
                        outline: 0;
                        color: white;
                        font-family: "Helvetica";
                        font-weight: bold;
                        border-top: 1px solid #3B8054; 
                    }

                    #nav li.active a
                    {
                        background: #1A6B38;
                        border-radius: 5px;
                        color: white;
                        font-family: "Helvetica";
                        font-weight: bold;
                    }

                    #nav > ul > li > ul
                    {
                        display: none;
                    }
                </style>
            </head>
            <body>

                <!-- Header -->
                <div id="header" class="headerAdmin">

                    <div class="container">
                        <?php
                        if ($_SESSION['login']['permiso'] == 'administrador') {
                            ?>
                            <nav id="nav">
                                <ul>
                                    <li><a href="panelAdmin.php">NOTICIAS</a></li>
                                    <li><a href="nuevoUsuario/nuevoUsuarioAdmin.php">USUARIOS</a></li>
                                    <li><a href="logout.php">SALIR</a></li>
                                </ul>
                            </nav>
                            <?php
                        }
                        ?>
                        <div id="tituloPanel">
                            <h1>PANEL DE ADMINISTRACIÓN</h1>
                        </div>

                    </div>
                </div>
                <!-- Header -->


                <div id="featured">
                    <div class="container">
                        <h2 class="tituloAdministracion">Gestión de Galeria</h2>
                        <div class="row" id="divPanel">
                            <a href="panelAdmin.php" id="nuevaNoticia"/><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Volver</a>
                            <a style="margin-left: 2px;" href="View/formularioInsertarImagen.php?idNoticia=<?= $_GET['id']; ?>" id="nuevaNoticia"/>Añadir&nbsp;✚</a>
                            <a style="margin-left: 2px;"  id="borrarImagen"/>Borrar <i class="fa fa-trash" aria-hidden="true"></i></a>
                            <a style="margin-left: 2px;"  id="hacerPrincipal"/>Hacer Principal <i class="fa fa-picture-o" aria-hidden="true"></i></a>

                            <div id="contenedorTabla">
                                <?php
                                $data['imagenes'] = Imagen::getImagenesByIdNoticia($_GET['id']);
                                foreach ($data['imagenes'] as $imagen) {
                                    if ($imagen->getNombre() != "") {
                                    ?>
                                    <img id="imagenGaleria" width="300px" src="images/<?= $imagen->getNombre() ?>" value="<?= $imagen->getIdImagen() ?>" file="<?= $imagen->getNombre() ?>" idNoticia="<?= $imagen->getIdNoticia() ?>">
                                    <?php
                                    }
                                }
                                ?>
                            </div> 
                        </div>          
                    </div>
                </div>

                <div id="dialogoHacerPrinciapal" title="Hacer imagen portada">¿Desea que esta imagen sea la portada de la notcia?</div>

                <div id="dialogoBorrar" title="Borrar Noticia">¿Desea borrar esta seleccion?</div>
            </body>
        </html>
        <?php
    }//Fin comprobacion de login
    else {//Si no estas logueado
        echo("<h1>Debes loguearte para visualizar esta página</h1>");
    }
} else {// Si no existe la variable de session login
    header('Location: login.php');
}
?>