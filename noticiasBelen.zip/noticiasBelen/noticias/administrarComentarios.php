<?php
require_once 'Model/Comentario.php';
session_start();
if (isset($_SESSION['login']['login'])) {


    if ($_SESSION['login']['login']) {
        ?>
        <!DOCTYPE HTML>
        <html>
            <head>
                <title>Noticias | Aceites Málaga</title>
                <meta http-equiv="content-type" content="text/html; charset=utf-8" />

                <meta name="description" content="" />
                <meta name="keywords" content="" />
                <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
                <link rel="shortcut icon" href="css/imagenes/favicon.png">
                <!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
                <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/skel-panels.min.js"></script>
                <script src="js/init.js"></script>
                <script src="paginadorAdminComentario.js" type="text/javascript"></script>
                <script src="js/borrarComentario.js" type="text/javascript"></script>
                <link href="js/jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
                <script src="js/jquery-ui-1.11.4.custom/jquery-ui.min.js" type="text/javascript"></script>
                <link href="fontAwesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
                <link href="fontAwesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
                <noscript>
                <link rel="stylesheet" href="css/skel-noscript.css" />
                <link rel="stylesheet" href="css/style.css" />
                <link rel="stylesheet" href="css/style-desktop.css" />
                <!--<link rel="stylesheet" href="fontAwesome/css/font-awesome.min.css" />-->
                </noscript>
                <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
                <!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
            </head>
            <body>

                <!-- Header -->
                <div id="header" class="headerAdmin">

                    <div class="container">
                        <?php
                        if ($_SESSION['login']['permiso'] == 'administrador') {
                            ?>
                            <nav id="navPanelAdmin">
                                <ul>
                                    <li><a href="panelAdmin.php">NOTICIAS</a></li>
                                    <li><a href="nuevoUsuario/nuevoUsuarioAdmin.php">USUARIOS</a></li>
                                </ul>
                            </nav>
                            <?php
                        }
                        ?>
                        <div id="tituloPanel">
                            <h1>PANEL DE ADMINISTRACIÓN</h1>
                        </div>

                    </div>
                </div>
                <!-- Header -->


                <div id="featured">
                    <div class="container">
                        <h2 class="tituloAdministracion">Gestión de comentarios</h2>
                        <div class="row" id="divPanel">
                            <a href="panelAdmin.php" id="nuevaNoticia"/>Volver</a>
                            <div id="contenedorTabla">
                                <?php include('paginadorAdminComentario.php') ?>
                            </div> 
                        </div>          
                    </div>
                </div>


                <div id="dialogoBorrar" title="Borrar Noticia">¿Desea borrar este comentario?</div>
            </body>
        </html>
        <?php
    }//Fin comprobacion de login
    else {//Si no estas logueado
        echo("<h1>Debes loguearte para visualizar esta página</h1>");
    }
} else {// Si no existe la variable de session login
    header('Location: login.php');
}
?>