$(function() {

	var app_id = '1182222928469038'; //id que nos da facebook al registrar la app
	var scopes = 'email, user_friends, user_online_presence'; //permisos que solicitamos al usuario

	var btn_login = '<a href="#" id="login" class="btn btn-block btn-social btn-facebook">' + 
                                    '<span class="fa fa-facebook"></span>' + 
                                    'Iniciar sesión'+
                                '</a>';

	var idUsuarioFacebook = null;
        var idComentario = null;
	window.fbAsyncInit = function() {

	  	FB.init({
	    	appId      : app_id,
	    	status     : true,
	    	cookie     : true, 
	    	xfbml      : true, 
	    	version    : 'v2.1'
	  	});


	  	FB.getLoginStatus(function(response) {
	    	statusChangeCallback(response, function() {});
	  	});
  	};

  	var statusChangeCallback = function(response, callback) {
  		console.log(response);
   		
    	if (response.status === 'connected') {
      		getFacebookData();
    	} else {
     		callback(false);
    	}
  	};

  	var checkLoginState = function(callback) {
    	FB.getLoginStatus(function(response) {
      		callback(response);
    	});
  	};

  	var getFacebookData =  function() {
  		FB.api('/me','GET', {fields: 'first_name, name,id,email'}, function(response) {
                    //Añadir al formulario datos (Nombre y email)
                        //Se añaden al final del formulario estos tres campos ocultos
                        $("#formularioComentario").append("<input type='hidden' name='usuario' value='"+response.name+"'/>"); 
                        $("#formularioComentario").append("<input type='hidden' name='idUsuarioFacebook' value='"+response.id+"'/>");
                        $("#formularioComentario").append("<input type='hidden' name='email' value='"+response.email+"'/>");
	  		//al iniciar sesión, aparezca la imagen al final la barra inicio
                        $("#barra").append("<li>" +
                                    "<img id='imagenSesion' class='media-object pull-left' src='http://graph.facebook.com/"+response.id+"/picture?type='large' alt='' width='35' height='35'/>"
                                    +"</li>");
                        //añadir boton de cerrar sesion    
                        $("#cajaCerrarSesion").append("<div id='botonCerrarSesion'>"+
					  "<strong></strong>"+
					  "<img>"+
					  "<a href='#' id='logout' class='btn btn-block btn-social btn-facebook'>" + 
                                    "<span class='fa fa-facebook'></span>" + 
                                    'Cerrar sesión'+
                                '</a>'+
					  "</div>");
                        //Se oculta el boton de iniciar sesión
                        $('#login').hide();
                        //Aparece btn de enviar comentario
                        $('#botonEnviar').show();
                        idUsuarioFacebook = response.id;
                        $("."+idUsuarioFacebook+" a").show();//Mostramos los enlaces a de editar y borrar de los comentarios que ha escrito el usuario
                        $(".editar").click(function(){//Funcion click boton editar
                            
                            if($(this).text() == "Editar"){
                                $(".editar").text("Editar"); //De esta manera evitamos que haya varios botones con cancelar
                                                              //si hay uno en cancelar y se pincha en editar de otro comentario
                                                              //quitaría el otro cancelar y pondría ese como cancelar.
                                $(this).text("Cancelar");
                                $("form[name="+idComentario+"]").hide(); 
                                $("p[name="+idComentario+"]").show();
                                idComentario = $(this).attr("name");
                                $("form[name="+idComentario+"]").show();
                                $("p[name="+idComentario+"]").hide();
                            
                                //$(".editar").click(function(){
                                    
                                //});
                            }else{
                                $(this).text("Editar");
                                $("form[name="+idComentario+"]").hide();
                                $("p[name="+idComentario+"]").show();
                            
                               
                            }
                            
                                   
                            
                            
                        });
                    });
                
  	};
        
  	var facebookLogin = function() {
  		checkLoginState(function(data) {
  			if (data.status !== 'connected') {
                                
                                $('#botonEnviar').hide();//si no esta conectado lo ocultamos para no enviar comentarios
  				FB.login(function(response) {
  					if (response.status === 'connected')
  						getFacebookData();
  				}, {scope:scopes});
  			}
  		});
  	};

  	var facebookLogout = function() {
  		checkLoginState(function(data) {
  			if (data.status === 'connected') {
				FB.logout(function(response) {
					$('#facebook-session').before(btn_login);
					$('#facebook-session').remove();
                                        $('#login').show(); //Muestra el botón de iniciar sesión
                                        $("."+idUsuarioFacebook+ " a").hide();
                                        idUsuarioFacebook = null;
				});
			}
  		});

  	};



  	$(document).on('click', '#login', function(e) {
  		e.preventDefault();

  		facebookLogin();
  	});

  	$(document).on('click', '#logout', function(e) {
  		e.preventDefault();
                
  		if (confirm("¿Está seguro?")){
                    $("#cajaCerrarSesion").hide();
                    $("#botonCerrarSesion").remove();
                    $("#botonEnviar").hide();
                    $('#imagenSesion').remove();
                    facebookLogout();
                }
                        
  		else 
  			return false;
  	});
        var clickSesion = false;//Variable global para gestionar ventana cerrar sesion
        $(document).on('click', '#imagenSesion', function(e) {
            if(clickSesion==false){
                clickSesion = true;
                $("#cajaCerrarSesion").show();
            }else{
                clickSesion = false;
                $("#cajaCerrarSesion").hide();
            }
            
  	});

        $("#botonEnviar").hide();
        
});
