<?php
require_once '../Model/BlogDB.php';
require_once '../Model/Noticia.php';
require_once '../Model/Comentario.php';
require_once '../Model/Usuario.php';
require_once '../Model/Imagen.php';

$connection = BlogDB::connectDB();


if (isset($_GET['id'])) {// Si pasamos ID
    $contadorGaleriaImagenes = 0;
    $idNoticia = $_GET['id'];
    $data['noticias'] = Noticia::getNoticiaByIdNoticia($idNoticia);
    $numeroVisita = 0;
    foreach ($data['noticias'] as $noticia) { //Obtiene num visitias de 
                                                //la noticia actual
        $numeroVisita = $noticia->getVisita();
    }
    Noticia::incrementarVisita($numeroVisita, $_GET['id']);
    ?>
    <!DOCTYPE html>
    <html lang="en">

        <head>
            <title>Noticias | Aceites Málaga</title>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="shortcut icon" href="../css/imagenes/favicon.png">

            <title>Noticias | Aceites Málaga</title>



            <!-- Bootstrap Core CSS -->
            <link href="css/bootstrap.min.css" rel="stylesheet">

            <!-- Custom CSS -->
            <link href="css/blog-post.css" rel="stylesheet">
            <link href="css/bootstrap-social.css" rel="stylesheet" type="text/css"/>
            <link href="../fontAwesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
            <link href="css/slide.css" rel="stylesheet" type="text/css"/>

        </head>

        <body>

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!-- Logo -->
                        <div id="logo">
                            <a href="../index.php"><img id="logoImg" src="../css/imagenes/acm.png"></a>
                        </div>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav" id="barra">
                            <li>
                                <a href="../index.php">Volver</a>
                            </li>
                            <li>
                                <a href="http://aceitesmalaga.com/">Nosotros</a>
                            </li>
                            <li>
                                <a href="http://aceitesmalaga.com/tienda">Tienda</a>
                            </li>

                        </ul>

                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container -->
            </nav>

            <!-- Page Content -->
            <div class="container">

                <div class="row">
                    <!-- Blog Post Content Column -->
                    <div class="col-lg-8">

                        <?php
                        $data['noticias'] = Noticia::getNoticiaByIdNoticia($idNoticia);
                        foreach ($data['noticias'] as $noticia) {
                            ?>

                            <!-- Blog Post -->

                            <!-- Title -->

                            <h1><?= $noticia->getTitulo() ?></h1>

                            <!-- Author -->
                            <p class="lead">
                                <?php
                                $data['usuarios'] = Usuario::getNombreUsuarioByIdUsuario($noticia->getIdUsuario());
                                foreach ($data['usuarios'] as $usuario) {
                                    ?>
                                    by <a href="#" id="author"><?= $usuario->getNombre() ?></a>
                                    <?php
                                }
                                ?>
                            </p>

                            <hr>

                            <!-- Date/Time -->
                            <div>
                                <?php
                                if ($noticia->getFechaModificacion() == null) {
                                    ?>     
                                    <span><b>Fecha de creación: </b><?= $noticia->getFecha() ?></span>
                                    <?php
                                } else {
                                    ?>     
                                    <span><b>Fecha de creación: </b><?= $noticia->getFecha() ?></span>
                                    <br>
                                    <span id="ultimaEdicion">Última edición: <?= $noticia->getFechaModificacion() ?></span>
                                    <?php
                                }
                                ?>
                                <div class="center-block">            
                                    <a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="http://www.facebook.com/sharer.php?u=http://localhost/Noticias/leerMas/index.php?<?= $idNoticia ?>" class="btn btn-social-icon btn-facebook"><span class="fa fa-facebook"></span></a>
                                    <a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="http://twitter.com/home?status=Mira%20esta%20noticia!!%20http://localhost/Noticias/leerMas/index.php?<?= $idNoticia ?>" class="btn btn-social-icon btn-twitter"><span class="fa fa-twitter"></span></a>
                                    <a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://plus.google.com/share?url=http://localhost/Noticias/leerMas/index.php?<?= $idNoticia ?>" class="btn btn-social-icon btn-google"><span class="fa fa-google-plus"></span></a>

                                </div>    
                            </div>
                            <hr>

                            <!-- Preview Image -->
                          
                            <div id="slider" >
                                <ul>
                                    <?php
                                    $data['imagenes'] = Imagen::getNombreImagenByIdNoticia($noticia->getIdNoticia());
                                    if ($noticia->getImagen() != null) {
                                        //if ($contadorGaleriaImagenes == 0) {
                                            ?>
                                            <li><img height="400px"  src="../images/<?= $noticia->getImagen() ?>" alt="image description"></li>  
                                            <?php
                                        //}
                                        foreach ($data['imagenes'] as $imagen) {
                                            if ($imagen->getNombre() != $noticia->getImagen()) {
                                                ?>
                                                <li><img height="400px"  src="../images/<?= $imagen->getNombre() ?>" alt="image description"></li>
                                                <?php
                                            }
                                        }
                                        
                                    }
                                    ?>
                                </ul>			

                            </div>

                            <hr>

                            <!-- Post Content -->
                            <p class="lead"><?= $noticia->getDescripcion() ?></p>

                            <?php
                            if ($noticia->getVideo() != null) {
                                ?>    
                                <div class="video-responsive">
                                    <?= $noticia->getVideo() ?>
                                </div>
                                <?php
                            }
                            ?>

                            <hr>
                            <?php
                        }
                        ?>
                        <!-- Blog Comments -->

                        <!-- Comments Form -->


                        <div class="well">
                            <h4>Deje un comentario:</h4>
                            <form role="form" action="../Controller/insertarComentario.php" method="POST" id="formularioComentario">
                                <div class="form-group">
                                    <textarea class="form-control" rows="3" name="comentario"></textarea>
                                </div>
                                <input type="hidden" value="<?= $idNoticia ?>" name="idNoticia">
                                <a href="#" id="login" class="btn btn-block btn-social btn-facebook">
                                    <span class="fa fa-facebook"></span>
                                    Iniciar sesión
                                </a>
                                <button type="submit" class="btn btn-primary" id="botonEnviar">Enviar</button>
                            </form>
                        </div>

                        <hr>

                        <!-- Posted Comments -->

                        <!-- Comment -->
                        <?php
                        $data['comentarios'] = Comentario::getComentariosByID($idNoticia);
                        foreach ($data['comentarios'] as $comentario) {
                            ?>
                            <div class="media <?= $comentario->getIdUsuarioFacebook() ?>">  <!-- Aquí empìeza cada comentario !-->
                                <!-- Si dos usuarios escriben dos comentario, le salen dos div con el misma clase (ID de facebook) y son los que puede editr/borrar !-->
                                <img class="media-object pull-left" src="http://graph.facebook.com/<?= $comentario->getIdUsuarioFacebook() ?>/picture?type=large" alt="" width="64" height="64">
                                    <!--Es la ruta de facebook donde se almacenan las fotos del perfil de todos los usuarios. !-->
                                <div class="media-body">
                                    <h4 class="media-heading"><?= $comentario->getUsuario() ?>
                                        <small><?= $comentario->getFecha() ?></small>
                                    </h4>
                                    <p name="<?= $comentario->getIdComentario() ?>"><?= $comentario->getComentario() ?></p>
                                    <form style="display:none;" action="../Controller/modificarComentario.php" method="POST" name="<?= $comentario->getIdComentario() ?>">
                                        <textarea name="comentario">
                                            <?= $comentario->getComentario() ?>
                                        </textarea>
                                        <input type="hidden" name="idComentario" value="<?= $comentario->getIdComentario() ?>"/>
                                        <input type="hidden" name="usuario" value="<?= $comentario->getUsuario() ?>"/>
                                        <input type="hidden" name="fecha" value="<?= $comentario->getFecha() ?>"/>
                                        <input type="hidden" name="idNoticia" value="<?= $comentario->getIdNoticia() ?>"/>
                                        <input type="hidden" name="idUsuarioFacebook" value="<?= $comentario->getIdUsuarioFacebook() ?>"/>
                                        <input type="hidden" name="email" value="<?= $comentario->getEmail() ?>"/>
                                        <input type="submit" value="Enviar"/>
                                    </form>
                                </div>
                                <a style="display:none;"class="editar" name="<?= $comentario->getIdComentario() ?>" >Editar</a>
                                <a style="display:none;" href="../Controller/borrarComentario.php?id=<?= $comentario->getIdComentario() ?>&idNoticia=<?= $noticia->getIdNoticia() ?>">Borrar</a>
                            </div>
                            <?php
                        }
                        ?>

                    </div>


                </div>
                <!-- /.row -->

                <hr>

                <!-- Footer -->
                <footer>
                    <div class="row">
                        <div class="col-lg-12">
                            <p id="copyright">Copyright © Aceites Málaga,S.L.</p>
                        </div>
                    </div>
                    <!-- /.row -->
                </footer>

            </div>
            <div id="cajaCerrarSesion"></div>
            <!-- /.container -->

            <!-- jQuery -->

            <script src="js/jquery.js"></script>
            <script src="js/jquery.sudoSlider.min.js" type="text/javascript"></script>
            <!-- Bootstrap Core JavaScript -->
            <script src="js/bootstrap.min.js"></script>
            <!-- Login facebook script -->    
            <script src="js/loginFacebook.js" type="text/javascript"></script>
            <script>
                                    // Load the SDK asynchronously
                                    (function (d, s, id) {
                                        var js, fjs = d.getElementsByTagName(s)[0];
                                        if (d.getElementById(id))
                                            return;
                                        js = d.createElement(s);
                                        js.id = id;
                                        js.src = "//connect.facebook.net/en_US/sdk.js";
                                        fjs.parentNode.insertBefore(js, fjs);
                                    }(document, 'script', 'facebook-jssdk'));
            </script>
            <script type="text/javascript">
                $(document).ready(function () {
                    var sudoSlider = $("#slider").sudoSlider({
                        numeric: true,
                        beforeAnimation: function (slide) {
                            $('div.descrip-text #anistate').text('Animating to slide ' + slide).show(600);
                        },
                        afterAnimation: function (slide) {
                            $('div.descrip-text #anistate').hide(400);
                            $('div.descrip-text #slidenumber').text(slide);
                            var text = $(this).children().attr('src');
                            $('div.descrip-text #slidehtml').text(text);
                        },
                        initCallback: function () {
                            var slide = this.getValue("currentSlide");
                            $('div.descrip-text #slidenumber').text(slide);

                            var text = this.getSlide(slide).children().attr('src');
                            $('div.descrip-text #slidehtml').text(text);
                        }
                    });
                });
            </script>
        </body>

    </html>
    <?php
}//Fin comprobacion existe GET ID
else {//Si no se selecciona ninguna noticia
    echo '<h1>Seleccione una noticia</h1>';
}
?>