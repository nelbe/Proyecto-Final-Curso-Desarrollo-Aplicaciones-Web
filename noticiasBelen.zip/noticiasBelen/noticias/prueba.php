<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>jQuery UI Datepicker - Entrada de texto</title>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.1/jquery-ui.js"></script>
<script src="js/jquery.ui.datepicker-es.js" type="text/javascript"></script>

<script>
$(function () {
$.datepicker.setDefaults($.datepicker.regional["es"]);
$("#datepicker").datepicker({
firstDay: 1
});
});
</script>
</head>

<body>
    <form method="POST" action="./prueba.php">
        Fecha:
        <input type="text" id="datepicker" name="fecha" />
        <input type="submit">
    </form>
<?php
if(isset($_POST['fecha'])){
    echo $_POST['fecha'];
}
?>
</body>
</html>